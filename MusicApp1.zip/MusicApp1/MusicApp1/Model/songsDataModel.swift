//
//  songsDataModel.swift
//  MusicApp1
//
//  Created by bashayer Al qaoud on 10/9/20.
//

import Foundation

struct song {
    var songName: String
    var songCover: String
    var SongArtist: String
    var audioName: String
}


var disneySongsData: [song] = [
            song(songName: "a whole new world", songCover: "a whole new world",  SongArtist: "Mena Massoud, Naomi Scott", audioName: " A Whole New World.mp3 .mp3"),
            song(songName: "can you feel the love", songCover: "can you feel the love", SongArtist: "The Lion king", audioName: "Can You Feel The Love Tonight.mp3"),
            song(songName: "how far i'll go", songCover: "how far i'll go", SongArtist: "Auli'i Cravalho", audioName: " How Far I'll Go.mp3"),
            song(songName: "remember me", songCover: "remember me", SongArtist: "coco", audioName: "Remember me .mp3")
]









var spacetoonSongsData = [
                song(songName: "بابار فيل", songCover: "بابار فيل", SongArtist: "رشا، ديمة طرقان، محمد طرقان", audioName: "بابار فيل.mp3"),
    song(songName: "عهد الأصدقاء", songCover: "عهد الأصدقاء", SongArtist: "رشا، طارق العربي طرقان", audioName: "عهد الأصدقاء.mp3"),
                song(songName: "ريمي", songCover: "ريمي", SongArtist: "spacetoon", audioName: "ريمي.mp3"),
                song(songName: "الحديقة السرية", songCover: "الحديقة السرية", SongArtist: "spacetoon", audioName: "الحديقة السرية.mp3")
]
