//
//  ViewController.swift
//  MusicApp1
//
//  Created by bashayer Al qaoud on 10/9/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func songButton(_ sender: UIButton) {
        if sender.tag == 0{
            performSegue(withIdentifier: "details", sender:disneySongsData )
        }else{
            performSegue(withIdentifier: "details", sender: spacetoonSongsData)
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! songChartTableViewController
        vc.selectData = sender as! [song]
    }
}

